module.exports = {
  'secret': 'iLoveWhenmyWifeLightsCandles',
  'database': './data.db'

}